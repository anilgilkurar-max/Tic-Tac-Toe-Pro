# Tic-Tac-Toe Pro — Android project

This project wraps the supplied HTML game in an Android WebView. The game runs offline from the bundled `app/src/main/assets/index.html`.

## Build an APK using GitHub Actions (phone-friendly)

1. Download and unzip this project.
2. Create a new repository on GitHub.
3. Upload all files and folders from this ZIP to the repository (keep the `.github` folder).
4. Open the repository's **Actions** tab and choose **Build Tic-Tac-Toe Pro APK**. Tap **Run workflow** if it hasn't started automatically.
5. When the run finishes, open it and download the artifact named **Tic-Tac-Toe-Pro-debug-apk**.
6. Extract the artifact ZIP; it contains `app-debug.apk`. Open it on your Android phone and allow installation from that source if Android asks.

This is a debug APK for personal testing, not a signed release for Play Store publishing.
